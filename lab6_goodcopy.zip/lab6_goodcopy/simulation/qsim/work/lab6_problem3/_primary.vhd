library verilog;
use verilog.vl_types.all;
entity lab6_problem3 is
    port(
        StudentID_Display: out    vl_logic_vector(0 to 6);
        Clock           : in     vl_logic;
        data_inFSM      : in     vl_logic;
        Reset_FSM       : in     vl_logic;
        truth_display   : out    vl_logic_vector(0 to 6);
        RegResets       : in     vl_logic;
        A               : in     vl_logic_vector(7 downto 0);
        B               : in     vl_logic_vector(7 downto 0);
        Enable_Decoder  : in     vl_logic
    );
end lab6_problem3;
