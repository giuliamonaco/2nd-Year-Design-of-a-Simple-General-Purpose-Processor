library verilog;
use verilog.vl_types.all;
entity dec4to16 is
    port(
        y               : out    vl_logic_vector(0 to 15);
        En              : in     vl_logic;
        w3              : in     vl_logic;
        w               : in     vl_logic_vector(2 downto 0)
    );
end dec4to16;
