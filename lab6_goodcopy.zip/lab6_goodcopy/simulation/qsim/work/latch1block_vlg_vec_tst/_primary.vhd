library verilog;
use verilog.vl_types.all;
entity latch1block_vlg_vec_tst is
end latch1block_vlg_vec_tst;
