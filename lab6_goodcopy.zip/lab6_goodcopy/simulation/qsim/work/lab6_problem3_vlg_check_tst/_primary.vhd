library verilog;
use verilog.vl_types.all;
entity lab6_problem3_vlg_check_tst is
    port(
        StudentID_Display: in     vl_logic_vector(0 to 6);
        truth_display   : in     vl_logic_vector(0 to 6);
        sampler_rx      : in     vl_logic
    );
end lab6_problem3_vlg_check_tst;
