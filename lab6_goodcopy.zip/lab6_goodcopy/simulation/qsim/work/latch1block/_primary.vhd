library verilog;
use verilog.vl_types.all;
entity latch1block is
    port(
        Q               : out    vl_logic_vector(7 downto 0);
        reset           : in     vl_logic;
        clk             : in     vl_logic;
        A               : in     vl_logic_vector(7 downto 0)
    );
end latch1block;
